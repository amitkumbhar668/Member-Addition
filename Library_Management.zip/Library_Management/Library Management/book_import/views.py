from django.http import JsonResponse
import requests
from datetime import datetime
from .models import Book
from django.shortcuts import render,redirect


def import_books(request):
    if request.method == 'POST':
        num_books_to_import = int(request.POST.get('num_books', 20))  # Default value is 20
        api_url = 'https://frappe.io/api/method/frappe-library'

        try:
            response = requests.get(api_url)
            response.raise_for_status() 

            api_data = response.json()

            books_imported = 0 
            for book_data in api_data['message']:
                if books_imported >= num_books_to_import:
                    break 

                try:
                    publication_date = datetime.strptime(book_data['publication_date'], '%m/%d/%Y').date()
                except ValueError:
                    print(f"Invalid date format for publication_date: {book_data['publication_date']}")
                    continue 

                Book.objects.create(
                    title=book_data['title'],
                    authors=book_data['authors'],
                    isbn=book_data['isbn'],
                    num_pages=int(book_data['  num_pages']),
                    publication_date=publication_date,
                    publisher=book_data['publisher'],
                    average_rating=0.0,  
                    ratings_count=0,
                    text_reviews_count=0,
                )

                books_imported += 1 

            print(f"{books_imported} books imported successfully.")
            return JsonResponse({'message': f"{books_imported} books imported successfully."})  

        except requests.RequestException as e:
            print(f'Error fetching data from API: {e}')
            return JsonResponse({'error': f'Error fetching data from API: {e}'}, status=500)  

    else:
        return render(request, 'import_books.html')


from django.views.generic.list import ListView
from django.views.generic.detail import DetailView
from django.views.generic.edit import CreateView,DeleteView,UpdateView,FormView
from django.urls import reverse_lazy

class BookList(ListView):

    model = Book
    context_object_name = 'Books'
    template_name = 'book_import/book_list.html'


class BookCreate(CreateView): 
    model = Book
    fields = "__all__"
    success_url = reverse_lazy('list') 
    template_name = 'book_import/book_create.html'


class BookDelete(DeleteView):
    model = Book
    template_name = 'book_import/book_delete.html'
    success_url = reverse_lazy('list')
    template_name = 'book_import/book_delete.html'
    
class BookUpdate(UpdateView):
    model = Book
    fields = '__all__'
    template_name = 'book_import/book_import_form.html'
    success_url = reverse_lazy('list')

class BookDetail(DetailView):
    model = Book
    context_object_name = 'Book'
    template_name = 'book_import/book_detail.html'



from django.contrib.auth.forms import UserCreationForm 
from django.contrib.auth import login 
class RegisterPage(FormView):
    template_name = 'book_import/register.html'
    form_class = UserCreationForm
    redirect_authenticated_user = True   
    success_url = reverse_lazy('list')

    def form_valid(self, form):
        user = form.save()
        if user is not None:
            login(self.request, user) 
        return super(RegisterPage,self).form_valid(form)
    
    def get(self, *args, **kwargs):
        if self.request.user.is_authenticated:
            return redirect('list')
        return super(RegisterPage, self).get(*args, **kwargs)


from django.contrib.auth.views import LoginView 

class CustomLoginView(LoginView):
    template_name = 'book_import/login.html'
    fields = '__all__'
    redirect_authenticated_user = True

    def get_success_url(self):
        return reverse_lazy('list')




