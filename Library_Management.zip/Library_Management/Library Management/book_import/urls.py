from django.urls import path
from . import views
from .views import BookList,BookCreate,BookDelete,BookUpdate,BookDetail,RegisterPage,CustomLoginView

from django.contrib.auth.views import LogoutView


urlpatterns = [
    path('import-books/', views.import_books, name='import_books'),
    path('', BookList.as_view(), name='list'),  #homepage
    path('create/', BookCreate.as_view(), name='create'),
    path('delete/<int:pk>/', BookDelete.as_view(), name='delete'),
    path('update/<int:pk>/', BookUpdate.as_view(), name='update'),
    path('details/<int:pk>/', BookDetail.as_view(), name='details'),
    path('register/', RegisterPage.as_view(), name='register'),
    path('login/', CustomLoginView.as_view(), name='login'),
    path('logout/', LogoutView.as_view(next_page='login'), name='logout'),


]
