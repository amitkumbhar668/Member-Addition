from django.db import models
from django.contrib.auth.models import User


class Book(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, null=True, blank=True)
    bookID = models.CharField(max_length=20)
    title = models.CharField(max_length=255)
    authors = models.CharField(max_length=255)
    average_rating = models.DecimalField(max_digits=4, decimal_places=2)
    isbn = models.CharField(max_length=13)
    isbn13 = models.CharField(max_length=13)
    language_code = models.CharField(max_length=3)
    num_pages = models.IntegerField()
    ratings_count = models.IntegerField()
    text_reviews_count = models.IntegerField()
    publication_date = models.DateField()
    publisher = models.CharField(max_length=255)

    def __str__(self):
        return self.title
