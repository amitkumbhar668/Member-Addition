from django.contrib import admin
from .models import Book
# Need to register our models here.

admin.site.register(Book)